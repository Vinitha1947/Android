# Android-Attendance-App



See Demo Here - https://projectworlds.in/android-projects-with-source-code/android-attendance-system-app-source-code/

More Project

Youtube Channel Link :https://www.youtube.com/channel/UCFMkpvtYjSAPXUPjImQK7bg?sub_confirmation=1


Android is the ideal platform for developing such an application due to the wide variety of devices it supports.

android developer, Java, Android Studio, Xml ·
It is a system developed in android studio through which
faculty can register the number of students in a particular
class then register the number of subjects in that class and can mark the attendance of the students.
<h2>Features Available</h2>
<h3>Admin Module</h3>
<ul>
 	<li>Add Student.</li>
 	<li>Add Faculty.</li>
 	<li>Add Teacher.</li>
 	<li>View Student.</li>
 	<li>View Teacher.</li>
 	<li>View Student Attendance.</li>
 	<li>View each student’s attendance separately</li>
</ul>
<h3>Teacher Module</h3>
<ul>
 	<li>Take attendance and keep them class wise</li>
 	<li>Add New student. View each student’s attendance separately</li>
 	<li>Edit Student/Attendance later</li>
 	<li>Save notes subject wise</li>
 	<li>Simple  designed interface</li>
</ul>
<h3 id="requirement" class="notes">Software Requirement</h3>
<ul>
 	<li>Android Studio</li>
 	<li>Latest Version</li>
 	<li>Internet Connection</li>
 	<li>Java</li>
</ul>
<h3>Admin Login</h3>
<ul>
 	<li>Username :-admin</li>
 	<li>Password :-admin123</li>
</ul>
&nbsp;
<h3>Installation :</h3>
